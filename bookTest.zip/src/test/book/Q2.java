package test.book;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Q2 {
   // 연결하기 위해 필요한 정보 (url, user, pwd)
   String URL = "jdbc:oracle:thin:@localhost:1521:xe";
   String USER = "c##madang";
   String PWD = "madang";
   
   Connection con;
   Scanner scanner;
   
   public Q2() {      
      // JDBC Driver Load 문장
      try {
         Class.forName("oracle.jdbc.driver.OracleDriver");
         System.out.println("드라이버 로드 성공");
         // Connection 객체 생성
         con = DriverManager.getConnection(URL, USER, PWD);
         System.out.println("DB 연결 성공");
         scanner = new Scanner(System.in);
      } catch (ClassNotFoundException e) {
         e.printStackTrace();
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }
   
   public void searchBooksByTitle(String keyword) {
      String sql = "SELECT * FROM book WHERE bookname LIKE ? ORDER BY bookid"; // 도서번호로 오름차순 정렬
      try {
         // PreparedStatement를 사용하여 SQL 인젝션을 방지
         PreparedStatement pstmt = con.prepareStatement(sql);
         pstmt.setString(1, "%" + keyword + "%");
         
         // SQL 실행 및 결과 집합 얻기
         ResultSet rs = pstmt.executeQuery();
         
         // 콘솔에 헤더 출력
         System.out.println("도서번호\t도서명\t가격");
         
         // 반복문을 사용해서 ResultSet 객체의 행 개수만큼 데이터를 가져와서 콘솔에 출력
         while (rs.next()) {
            int bookId = rs.getInt("bookid");
            String bookName = rs.getString("bookname");
            int price = rs.getInt("price");
            
            System.out.println("\t" + bookId + "\t" + bookName + "\t" + price);
         }
         
         pstmt.close();
      } catch (SQLException e) {
         e.printStackTrace();
      }
   }
   
   public static void main(String[] args) {
      Q2 bookSearch = new Q2();
      System.out.print("도서명 일부를 입력하세요: ");
      String keyword = bookSearch.scanner.nextLine();
      bookSearch.searchBooksByTitle(keyword);
   }
}